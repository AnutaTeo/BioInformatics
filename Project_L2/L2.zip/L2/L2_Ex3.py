#exercitiul 3

#design an application using the AI which contains GUI which allows the user to select a Fasta File. The content of the file should be analyzed by using a sliding window of 30 positions
#the content of each sliding window should be used in order to extract the percentage of the relative frequencies of the symbols found in the alphabet of the sequence
#Thus your input should be the DNA sequence from the FASTA file and the output should be the values of the relative frequencies of each symbol from the sequence. Translate
# in lines on a chart. Thus your chart in the case of DNA should have 4 lines which reflect the values found over the sequence.


import tkinter as tk
from tkinter import filedialog, messagebox
import matplotlib.pyplot as plt
from collections import Counter

WINDOW_SIZE = 30

def analyze_fasta():
    filepath = filedialog.askopenfilename(
        title = "Select FASTA file",
        filetypes = (("FASTA files", "*.fasta"), ("All files", "*.*"))
    )
    if not filepath:
        print("No file selected. Exiting.")
        return

    try:
        with open(filepath, "r") as f:
            lines = f.readlines()

        seq = "".join(line.strip() for line in lines if not line.startswith(">")).upper()
        n = len(seq)

        if n == 0:
            messagebox.showerror("Error", "No sequence found in file!")
            return

        text_output.delete("1.0", tk.END)
        text_output.insert(tk.END, f"Sequence length: {n}\n")
        text_output.insert(tk.END, f"Sliding window size: {WINDOW_SIZE}\n\n")

        A_freq = []
        C_freq = []
        G_freq = []
        T_freq = []

        for i in range(n - WINDOW_SIZE + 1):
            window = seq[i:i+WINDOW_SIZE]
            counts = Counter(window)
            total = sum(counts.values())

            A_freq.append(counts.get("A", 0) / total)
            C_freq.append(counts.get("C", 0) / total)
            G_freq.append(counts.get("G", 0) / total)
            T_freq.append(counts.get("T", 0) / total)

        text_output.insert(tk.END, "Relative frequencies calculated.\n")
        text_output.insert(tk.END, "Plotting graph...\n")

        x = list(range(len(A_freq)))

        plt.figure(figsize=(10, 6))
        plt.plot(x, A_freq, label="A", color='red')
        plt.plot(x, C_freq, label="C", color='blue')
        plt.plot(x, G_freq, label="G", color='green')
        plt.plot(x, T_freq, label="T", color='orange')

        plt.xlabel("Sliding Window Position")
        plt.ylabel("Relative Frequency")
        plt.title("Relative Frequencies of Nucleotides (Window = 30)")
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        plt.show()

    except Exception as e:
        messagebox.showerror("Error", str(e))

root = tk.Tk()
root.title("FASTA Sliding Window Analyzer")

frame = tk.Frame(root, padx=10, pady=10)
frame.pack()

btn = tk.Button(frame, text="Open FASTA File", command=analyze_fasta)
btn.pack(pady=5)

text_output = tk.Text(frame, width=50, height=10)
text_output.pack()

root.mainloop()
