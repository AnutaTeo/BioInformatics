#The melting temperature (Tm) is the temperature at which one-half of a particular DNA duplex will dissociate and become a single strand of DNA. 
# Primer length and sequence are of critical importance in designing the parameters of a successful amplification. 
# The melting temperature of a nucleic acid duplex increases both with its length, and with increasing GC content. 

import math

def calculate_tm_simple(dna):
    dna = dna.upper()
    g = dna.count('G')
    c = dna.count('C')
    a = dna.count('A')
    t = dna.count('T')
    tm = 4 * (g + c) + 2 * (a + t)
    return tm

def calculate_tm_advanced(dna, na_concentration=0.05):
    
    dna = dna.upper()
    length = len(dna)
    if length == 0:
        return None

    g = dna.count('G')
    c = dna.count('C')
    gc_percent = ((g + c) / length) * 100

    tm = 81.5 + 16.6 * math.log10(na_concentration) + 0.41 * gc_percent - (600 / length)
    return tm


dna_input = input("Enter a DNA sequence: ").strip()

tm1 = calculate_tm_simple(dna_input)
tm2 = calculate_tm_advanced(dna_input)

print(f"Tm (Simple Formula): {tm1:.2f} °C")

if tm2 is not None:
    print(f"Tm (Alternative Formula): {tm2:.2f} °C")
else:
    print("Invalid DNA length for alternative formula.")
