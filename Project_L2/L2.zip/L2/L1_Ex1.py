#exercitiul 1

#Find the percentage for all the dinucleotide and trinucleotide combinations for the sequence: S="TACGTGCGCGCGAGCTATCTACTGACTTACGACTAGTGTAGCTGCATCATCGATCGA".
#1. Build a brute force engine to generate all dinucleotide and trinucleotide combinations.
#2. For each combination, find out the percentage inside the S sequence.
#3. Show the percentage for each combination in the output of your implementation.

S = "TACGTGCGCGCGAGCTATCTACTGACTTACGACTAGTGTAGCTGCATCATCGATCGA"

nucleotides = ['A', 'C', 'G', 'T']

def percentage(pattern, sequence):
    count = 0
    for i in range(len(sequence) - len(pattern) + 1):
        if sequence[i:i+len(pattern)] == pattern:
            count = count + 1
    total = len(sequence) - len(pattern) + 1
    return (count / total) * 100


dinucleotides = []
for n1 in nucleotides:
    for n2 in nucleotides:
        dinucleotides.append(n1 + n2)


trinucleotides = []
for n1 in nucleotides:
    for n2 in nucleotides:
        for n3 in nucleotides:
            trinucleotides.append(n1 + n2 + n3)

print("Dinucleotides: ", dinucleotides, "\n")
print("Trinucleotides: ", trinucleotides)

print("Dinucleotide percentages:")
for d in dinucleotides:
    print(f"{d}: {percentage(d, S):.2f}%")

print("\nTrinucleotide percentages:")
for t in trinucleotides:
    print(f"{t}: {percentage(t, S):.2f}%")