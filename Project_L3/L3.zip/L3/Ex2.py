import tkinter as tk
from tkinter import filedialog, messagebox
import matplotlib.pyplot as plt

WINDOW_SIZE = 8

def calculate_tm_simple(dna):
    dna = dna.upper()
    g = dna.count('G')
    c = dna.count('C')
    a = dna.count('A')
    t = dna.count('T')
    return 4 * (g + c) + 2 * (a + t)

def analyze_fasta():
    filepath = filedialog.askopenfilename(
        title="Select FASTA file",
        filetypes=(("FASTA files", "*.fasta"), ("All files", "*.*"))
    )
    if not filepath:
        print("No file selected.")
        return

    try:
        with open(filepath, "r") as f:
            lines = f.readlines()
        seq = "".join(line.strip() for line in lines if not line.startswith(">")).upper()
        n = len(seq)

        if n == 0:
            messagebox.showerror("Error", "No sequence found in file!")
            return

        text_output.delete("1.0", tk.END)
        text_output.insert(tk.END, f"Sequence length: {n}\n")
        text_output.insert(tk.END, f"Sliding window size: {WINDOW_SIZE}\n\n")

        tm_values = []
        window_sequences = []

        for i in range(n - WINDOW_SIZE + 1):
            window = seq[i:i+WINDOW_SIZE]
            tm = calculate_tm_simple(window)
            tm_values.append(tm)
            window_sequences.append(window)
            text_output.insert(tk.END, f"Window {i+1}: Seq = {window} | Tm = {tm:.2f} °C\n")

        text_output.insert(tk.END, f"\nCalculated {len(tm_values)} Tm values.\n")
        text_output.insert(tk.END, "Plotting graph...\n")

        x = list(range(len(tm_values)))
        plt.figure(figsize=(10, 6))
        plt.plot(x, tm_values, label="Tm (°C)", color='red')
        plt.xlabel("Sliding Window Position")
        plt.ylabel("Melting Temperature (°C)")
        plt.title(f"Melting Temperature along sequence (Window = {WINDOW_SIZE})")
        plt.grid(True)
        plt.legend()
        plt.tight_layout()
        plt.show()

    except Exception as e:
        messagebox.showerror("Error", str(e))

root = tk.Tk()
root.title("Tm Sliding Window Analyzer")

frame = tk.Frame(root, padx=10, pady=10)
frame.pack()

btn = tk.Button(frame, text="Open FASTA File", command=analyze_fasta)
btn.pack(pady=5)

text_output = tk.Text(frame, width=60, height=20)
text_output.pack()

root.mainloop()
