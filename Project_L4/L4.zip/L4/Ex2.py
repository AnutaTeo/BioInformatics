#download from NCBI the FASTA files containing the COVID-19 genome and the influenza genome. use AI to compare the codon frequencies between the two. 
#a)make a chart that shows the top 10 most frequent codons for COVID-19. 
#b)make a chart that shows the top 10 most frequent codons for influenza 
#c)compare the two results and show the most frequent codons between the two
#d)show in the output of the console top 3 amino acids for each genome

import matplotlib.pyplot as plt
from collections import Counter

genetic_code = {
    'TTT':'Phe', 'TTC':'Phe', 'TTA':'Leu', 'TTG':'Leu',
    'CTT':'Leu', 'CTC':'Leu', 'CTA':'Leu', 'CTG':'Leu',
    'ATT':'Ile', 'ATC':'Ile', 'ATA':'Ile', 'ATG':'Met',
    'GTT':'Val', 'GTC':'Val', 'GTA':'Val', 'GTG':'Val',

    'TCT':'Ser', 'TCC':'Ser', 'TCA':'Ser', 'TCG':'Ser',
    'CCT':'Pro', 'CCC':'Pro', 'CCA':'Pro', 'CCG':'Pro',
    'ACT':'Thr', 'ACC':'Thr', 'ACA':'Thr', 'ACG':'Thr',
    'GCT':'Ala', 'GCC':'Ala', 'GCA':'Ala', 'GCG':'Ala',

    'TAT':'Tyr', 'TAC':'Tyr', 'TAA':'Stop', 'TAG':'Stop',
    'CAT':'His', 'CAC':'His', 'CAA':'Gln', 'CAG':'Gln',
    'AAT':'Asn', 'AAC':'Asn', 'AAA':'Lys', 'AAG':'Lys',
    'GAT':'Asp', 'GAC':'Asp', 'GAA':'Glu', 'GAG':'Glu',

    'TGT':'Cys', 'TGC':'Cys', 'TGA':'Stop', 'TGG':'Trp',
    'CGT':'Arg', 'CGC':'Arg', 'CGA':'Arg', 'CGG':'Arg',
    'AGT':'Ser', 'AGC':'Ser', 'AGA':'Arg', 'AGG':'Arg',
    'GGT':'Gly', 'GGC':'Gly', 'GGA':'Gly', 'GGG':'Gly'
}

def read_fasta(file_path):
    seq = []
    with open(file_path, 'r') as f:
        for line in f:
            if line.startswith('>'):
                continue
            seq.append(line.strip().upper())
    return ''.join(seq)

def get_codon_frequencies(seq):
    codons = [seq[i:i+3] for i in range(0, len(seq)-2, 3)]
    codons = [c for c in codons if len(c) == 3]
    return Counter(codons)

def plot_top_codons(freq_dict, title):
    top10 = freq_dict.most_common(10)
    codons, counts = zip(*top10)
    plt.figure(figsize=(10,6))
    plt.bar(codons, counts, color='skyblue')
    plt.title(title)
    plt.xlabel('Codons')
    plt.ylabel('Frequency')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

def codons_to_amino_acids(freq_dict):
    aa_counter = Counter()
    for codon, count in freq_dict.items():
        aa = genetic_code.get(codon, '???')
        if aa != 'Stop' and aa != '???':
            aa_counter[aa] += count
    return aa_counter

def main():
    covid_file = "C:/Users/amamt/Desktop/BioInf/Lab4/covid-19-nov-2021-sequence.fasta"
    flu_file = "C:/Users/amamt/Desktop/BioInf/Lab4/influenza-river-sequence.fasta"

    covid_seq = read_fasta(covid_file)
    flu_seq = read_fasta(flu_file)

    covid_codons = get_codon_frequencies(covid_seq)
    flu_codons = get_codon_frequencies(flu_seq)

    # a) Top 10 COVID codons
    plot_top_codons(covid_codons, "Top 10 Codons - COVID-19")

    # b) Top 10 Influenza codons
    plot_top_codons(flu_codons, "Top 10 Codons - Influenza")

    # c) Compare most frequent codons
    covid_top = dict(covid_codons.most_common(10))
    flu_top = dict(flu_codons.most_common(10))
    common = set(covid_top.keys()) & set(flu_top.keys())
    print("\nCommon codons in top 10 of both genomes:", common)

    # d) Top 3 amino acids for each genome
    covid_aa = codons_to_amino_acids(covid_codons)
    flu_aa = codons_to_amino_acids(flu_codons)

    print("\nTop 3 amino acids (COVID-19):")
    for aa, c in covid_aa.most_common(3):
        print(f"{aa}: {c}")

    print("\nTop 3 amino acids (Influenza):")
    for aa, c in flu_aa.most_common(3):
        print(f"{aa}: {c}")

if __name__ == "__main__":
    main()
