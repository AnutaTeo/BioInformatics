#exercitiul 2

#find in a sequence S only the dinucleotides and trinucleotides that exists, without the use of brute force engine. 
#in order to achieve the results, one must check this combination starting from the beginning of the sequence until the end. 
#example  s = abaa

S = "TACGTGCGCGCGAGCTATCTACTGACTTACGACTAGTGTAGCTGCATCATCGATCGA"

dinucleotides = []
trinucleotides = []

for i in range(len(S) - 1):
    d = S[i:i+2]
    if d not in dinucleotides:
        dinucleotides.append(d)

for i in range(len(S) - 2):
    t = S[i:i+3]
    if t not in trinucleotides:
        trinucleotides.append(t)

print("Dinucleotides in the sequence:", dinucleotides, "\n")
print("Trinucleotides in the sequence:", trinucleotides)